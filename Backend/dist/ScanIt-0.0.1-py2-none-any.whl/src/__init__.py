from flask import Flask

REST = Flask(__name__)
